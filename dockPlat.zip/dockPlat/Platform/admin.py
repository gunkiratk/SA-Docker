from django.contrib import admin

from .models import Container

admin.site.register(Container)