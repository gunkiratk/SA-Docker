from django.apps import AppConfig


class PlatformConfig(AppConfig):
    name = 'Platform'
